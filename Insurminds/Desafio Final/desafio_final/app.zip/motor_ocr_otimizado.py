# Instalação no Colab (ignore se já tiver instalado no local)
# %pip install -qqq pytesseract opencv-python matplotlib

#Importações necessárias
import cv2 # OPEN-CV para manipulação de imagens
from pytesseract import image_to_string, pytesseract # TESSERACT para OCR
import pdf2image
import numpy as np
from os import name
from magic import from_buffer
from pathlib import Path

ENV_PATH = (
                 Path(__file__) # O CAMINHO DO ARQUIVO ATUAL
                .resolve() # RESOLVE O CAMINHO ABSOLUTO
                .parent # RETORNA O CAMINHO DA PASTA PAI DO ARQUIVO ATUAL
            )


class NotaFiscalOCR:
    """
    Classe responsável por realizar OCR em notas fiscais eletrônicas,
    utilizando Tesseract e OpenCV com pré-processamento.

    Atributos:
        lang (str): Idioma para o Tesseract (padrão 'por').
    """
    
    def __init__(self, lang='por'):
        """
        Inicializa a classe NotaFiscalOCR.

        Args:
            lang (str): Idioma para o Tesseract. Default é 'por' (português).
        """
        self.lang = lang

        # PARA WINDOWS
        if name == 'nt':
            self.tesseract_cmd = "C:\\Program Files\\Tesseract-OCR\\tesseract.exe" 
            self.poppler_path = f"{ENV_PATH}/poppler/poppler/poppler-24.08.0/Library/bin"
            
        
        # PARA LINUX
        elif name == 'posix':
            self.tesseract_cmd = "/usr/bin/tesseract"            
                        
        pytesseract.tesseract_cmd = self.tesseract_cmd
        

    def carregar_arquivo(self, caminho_imagem):
        """
        Carrega a imagem da nota fiscal a partir do caminho informado.

        Args:
            caminho_imagem (str): Caminho do arquivo de imagem.

        Returns:
            numpy.ndarray: Imagem carregada.

        Exception:
            FileNotFoundError: Se o arquivo não for encontrado.
        """
        
        tipo = from_buffer(caminho_imagem, mime=True)
                        
        if tipo == 'application/pdf' or (tipo == 'application/octet-stream' and caminho_imagem.name.endswith('.pdf')):
            return self.carregar_pdf(caminho_imagem)
        
        else:
            print('\nExtraindo o texto da imagem...')
                        
            file_bytes = np.asarray(bytearray(caminho_imagem), dtype=np.uint8) # UTLIZANDO O ARQUIVO EM MEMÓRIA
            imagem = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
                        
            if imagem is None or imagem.size == 0:
                raise FileNotFoundError(f"Imagem não encontrada ou vazia")

            return imagem
    
    def carregar_pdf(self, caminho_pdf):
        """
        Carrega um PDF e converte a primeira página em imagem.

        Args:
            caminho_pdf (str): Caminho do arquivo PDF.

        Returns:
            numpy.ndarray: Imagem da primeira página do PDF.

        Exception:
            FileNotFoundError: Se o arquivo não for encontrado.
        """
        
        print('\nExtraindo o texto do PDF...')
        
        if name == 'nt':
            imagens = pdf2image.convert_from_bytes(caminho_pdf, poppler_path=self.poppler_path)
            
        elif name == 'posix':
            imagens = pdf2image.convert_from_bytes(caminho_pdf)
            
        if not imagens:
            raise FileNotFoundError(f"PDF não encontrado ou vazio")
            
        
        return cv2.cvtColor(np.array(imagens[0]), cv2.COLOR_RGB2BGR) # IMAGENS[0] É A PRIMEIRA PÁGINA DO PDF, CONVERTIDA PARA FORMATO COMPATÍVEL COM OPENCV
    

    def preprocessar_imagem(self, imagem):
        """
        Realiza pré-processamento na imagem:
        - Conversão para escala de cinza.
        - Binarização com threshold fixo.

        Args:
            imagem (numpy.ndarray): Imagem original.

        Returns:
            numpy.ndarray: Imagem binarizada.
        """
        cinza = cv2.cvtColor(imagem, cv2.COLOR_BGR2GRAY) 
                     
        _, binarizada = cv2.threshold(cinza, 150, 255, cv2.THRESH_BINARY)
        
        return binarizada
        
    def extrair_texto(self, imagem_processada):
        """
        Executa o OCR utilizando Tesseract na imagem processada.

        Args:
            imagem_processada (numpy.ndarray): Imagem binarizada.

        Returns:
            str: Texto extraído.
        """
        #config = r'--oem 3 --psm 6 -l {}'.format(self.lang)
        config = r'--oem 3 --psm 11 -l {}'.format(self.lang)
        
        #config += ' -c tessedit_char_whitelist=0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,-/()$%:' #INSERIDO
    
        texto = image_to_string(imagem_processada, config=config)
        
        return texto    

    def main(self, caminho_arquivo) -> str:
        """
        Executa o pipeline completo:
        - Carrega e exibe a imagem original.
        - Pré-processa e exibe a imagem binarizada.
        - Realiza OCR e imprime o texto extraído.
        - Extrai campos específicos e os exibe.

        Args:
            caminho_arquivo (str): Caminho do arquivo da nota fiscal.

        Returns:
            tuple: Texto extraído (str), campos extraídos (dict)
        """
        imagem = self.carregar_arquivo(caminho_arquivo)
        imagem_proc = self.preprocessar_imagem(imagem)
        
        texto = self.extrair_texto(imagem_proc)
        print("Texto extraído:\n")
        print(texto)

        return texto