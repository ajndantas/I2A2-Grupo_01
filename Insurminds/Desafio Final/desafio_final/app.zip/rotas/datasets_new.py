from fastapi import APIRouter, File, UploadFile, Depends
from pydantic import BaseModel
from app.modelos.datasetquery import DatasetQuery
from app.modelos.outputschema import OutputSchema
from app.motor_ocr_otimizado import NotaFiscalOCR
from pathlib import Path
from functools import lru_cache
from typing import List
from fastapi import Request, HTTPException
import uuid

""" 
    Modifique os códigos de app.zip e frontend.zip, para que as seguintes ações possam ser realizadas:

    1 - Possa ser feito o upload de mais de um arquivo 
    2 - Ao se realizar o upload, possa ser associado um dataset para cada um deles, aonde esse dataset_id é gerado pelo código dataset.py, endpoint/api/datasets/uploads
    3 - No momento em que a pergunta foi submetida, os dataset_ids que foram gerados, sejam enviados para o endpoint "/{dataset_ids}/query" 
"""

ENV_PATH = (
                 Path(__file__) # O CAMINHO DO ARQUIVO ATUAL
                .resolve() # RESOLVE O CAMINHO ABSOLUTO
                .parent # RETORNA O CAMINHO DA PASTA PAI DO ARQUIVO ATUAL
                .parent # RETORNA O CAMINHO DA PASTA PAI DO ARQUIVO ATUAL
            )

#print("ENV_PATH: ", ENV_PATH)

@lru_cache
def getAgenteRag():

    from app.agente_rag import AgenteRag
    
    return AgenteRag()


router = APIRouter(
    prefix="/api/datasets"
)


# Armazenamento em memória ISOLADO POR SESSÃO:
#   sessions[session_id][dataset_id] = {"filename": str, "text": str}
# O session_id fica no cookie de sessão (SessionMiddleware). Cada "Nova análise" descarta a sessão
# anterior e cria outra, de modo que arquivos de análises diferentes nunca se misturam.
sessions: dict[str, dict[str, dict]] = {}


def _criar_sessao(request: Request) -> str:
    """Cria uma sessão nova e a associa ao cookie do request, descartando a anterior (se houver)."""
    anterior = request.session.get("session_id")
    if anterior:
        sessions.pop(anterior, None) # Libera da memória os datasets da sessão anterior

    request.session.clear()
    session_id = uuid.uuid4().hex
    sessions[session_id] = {}
    request.session["session_id"] = session_id
    return session_id


def _obter_sessao(request: Request) -> dict:
    """Retorna os datasets da sessão atual; cria uma sessão caso ainda não exista (ou tenha expirado)."""
    session_id = request.session.get("session_id")
    if not session_id or session_id not in sessions:
        session_id = _criar_sessao(request)
    return sessions[session_id]


class DatasetQuery(BaseModel):
    question: str

@router.post("/uploads")
async def uploads(request: Request, files: List[UploadFile] = File(...), ocr = Depends(NotaFiscalOCR)):

    from magic import from_buffer 

    session_datasets = _obter_sessao(request) # Datasets da sessão atual (isolados das demais sessões)

    novos_ids = []
    novos_filenames = []

    for file in files:

        dataset_id = f'ds_{uuid.uuid4().hex[:8]}' # ID único, sem risco de colisão como no random.randint(1, 9999)

        print("dataset_id: ", dataset_id)
        print("filename: ", file.filename)
    
        uploaded_file = await file.read() # EM MEMÓRIA
        filename = file.filename
        
        file_type = from_buffer(uploaded_file, mime=True)
        print("Filetype: ",file_type)

        if file_type not in ["text/plain", "text/csv"]: # Se o arquivo for PDF ou imagem, o OCR irá extrair o texto
            text = ocr.main(uploaded_file)

        else: # Se o arquivo for CSV ou TXT, o texto é lido diretamente da memória
            text = uploaded_file.decode("utf-8")

        session_datasets[dataset_id] = {"filename": filename, "text": text}

        novos_ids.append(dataset_id)
        novos_filenames.append(filename)

    # Retorna somente os datasets deste upload, na mesma ordem dos arquivos enviados
    # (o frontend associa arquivo -> dataset_id pelo índice).
    return {
                "dataset_ids": novos_ids, 
                "status": "ready",
                "filenames": novos_filenames
            }


@router.post("/sessions/new", summary="Iniciar uma nova sessão")
async def new_session(request: Request):
    """Chamado pelo botão 'Nova análise': descarta a sessão atual (e seus datasets) e cria uma nova."""
    session_id = _criar_sessao(request)
    return {"session_id": session_id, "status": "new"}


@router.post(
            "/{dataset_ids}/query",
            summary="Consultar datasets",
            description=(
                "Informe os IDs dos datasets separados por vírgula no caminho. "
                "Exemplo: `/api/datasets/ds_123,ds_456/query`."
            ),
            response_model=OutputSchema
        ) # Dataset_ids recebe uma string com os dataset_ids separados por vírgula
async def query_dataset(dataset_ids: str, payload: DatasetQuery, request: Request, ag = Depends(getAgenteRag)) -> OutputSchema: # O segundo parâmetro é o payload e não
                                                                                              # deve ser de tipo primitivo, porque o 
                                                                                              # frontend irá enviar no CORPO do JSON.
                                                                                              #
    import json                                                                               # Também poderia ser question: str = Body[...]        

        
    session_id = request.session.get("session_id")
    session_datasets = sessions.get(session_id)

    if session_datasets is None:
        raise HTTPException(status_code=404, detail="Sessão não encontrada ou expirada. Inicie uma nova análise.")

    ids = [d.strip() for d in dataset_ids.split(",") if d.strip()]
    desconhecidos = [d for d in ids if d not in session_datasets]

    if not ids or desconhecidos:
        raise HTTPException(status_code=404, detail=f"Dataset(s) não encontrado(s) na sessão atual: {', '.join(desconhecidos) or dataset_ids}")

    # Contexto montado SOMENTE com os datasets da sessão informados na rota (chave = nome do arquivo)
    context = {}
    for d in ids:
        nome = session_datasets[d]["filename"]
        if nome in context: # Dois arquivos com o mesmo nome: diferencia pelo dataset_id
            nome = f"{nome} ({d})"
        context[nome] = session_datasets[d]["text"]

    answer = json.loads(ag.query(question=payload.question, context=context))
    
    if answer["type"] == "table":
        output = OutputSchema(answer=answer["answer"], type=answer["type"], table=answer["table"], chart=None)
        
    elif answer["type"] == "chart":
        output = OutputSchema(answer=answer["answer"], type=answer["type"], table=None, chart=answer["chart"])
        
    elif answer["type"] == "mixed":
        output = OutputSchema(answer=answer["answer"], type=answer["type"], table=answer["table"], chart=answer["chart"])
        
    elif answer["type"] == "text":
        output = OutputSchema(answer=answer["answer"], type=answer["type"], table=None, chart=None)

    output.model_dump(exclude_none=True) # Remove os campos nulos da resposta
    
    #print("Pergunta: ", payload.question, "Resposta: ", answer['resposta'])

    # Os datasets NÃO são mais apagados após a consulta: a sessão continua válida para novas perguntas
    # e só é descartada quando o usuário clica em "Nova análise" (POST /api/datasets/sessions/new).

    return output